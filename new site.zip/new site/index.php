<?php
require 'config.php';

// ডাটাবেস কানেকশন
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// শর্ট লিংক জেনারেট লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['url'])) {
    $long_url = filter_var($_POST['url'], FILTER_VALIDATE_URL);
    
    if ($long_url) {
        $short_code = substr(md5(uniqid()), 0, 6);
        
        try {
            $stmt = $pdo->prepare("INSERT INTO links (long_url, short_code) VALUES (?, ?)");
            $stmt->execute([$long_url, $short_code]);
            $short_url = BASE_URL . '/' . $short_code;
            $success = "Your short URL: <a href='$short_url' target='_blank'>$short_url</a>";
        } catch(PDOException $e) {
            $error = "Error: " . ($e->getCode() == 23000 ? "Short code already exists, please try again" : "Database error");
        }
    } else {
        $error = "Please enter a valid URL (e.g., https://example.com)";
    }
}

// রিডাইরেক্ট লজিক
if (isset($_GET['q'])) {
    $stmt = $pdo->prepare("SELECT long_url FROM links WHERE short_code = ?");
    $stmt->execute([$_GET['q']]);
    $url = $stmt->fetchColumn();
    
    if ($url) {
        // ক্লিক কাউন্ট আপডেট
        $pdo->prepare("UPDATE links SET clicks = clicks + 1 WHERE short_code = ?")->execute([$_GET['q']]);
        header("Location: $url");
        exit;
    } else {
        header("HTTP/1.0 404 Not Found");
        die("Short link not found");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL Shortener</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f7fa;
            color: #333;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        input[type="url"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border 0.3s;
        }
        input[type="url"]:focus {
            border-color: #3498db;
            outline: none;
        }
        button {
            background: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background 0.3s;
        }
        button:hover {
            background: #2980b9;
        }
        .error {
            color: #e74c3c;
            margin-top: 10px;
            padding: 10px;
            background: #fadbd8;
            border-radius: 5px;
        }
        .success {
            color: #27ae60;
            margin-top: 20px;
            padding: 15px;
            background: #d5f5e3;
            border-radius: 5px;
            word-break: break-all;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #7f8c8d;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>URL Shortener</h1>
        <form method="POST">
            <input type="url" name="url" placeholder="Enter your long URL (e.g., https://example.com)" required>
            <button type="submit">Shorten URL</button>
        </form>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php elseif (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="footer">
            <p>A simple URL shortener service | <?php echo date('Y'); ?></p>
        </div>
    </div>
</body>
</html>